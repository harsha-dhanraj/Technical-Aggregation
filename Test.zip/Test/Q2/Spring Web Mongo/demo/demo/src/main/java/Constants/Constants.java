package Constants;

public class Constants {

    public static final String database = "SpringWeb";
    public static final String collection = "TestingSpring";

}
